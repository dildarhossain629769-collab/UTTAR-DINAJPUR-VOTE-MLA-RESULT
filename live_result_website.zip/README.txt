HOW TO USE:

1. Open index.html
2. Replace the Google Sheet CSV link in the code
3. Upload to hosting (or open locally)
4. Update your Google Sheet → website auto updates

IMPORTANT:
- Sheet must be published as CSV
- Link format: .../pub?output=csv
